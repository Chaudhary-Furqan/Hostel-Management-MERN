module.exports = {
  mongoURI: "mongodb+srv://furqan:387726@cluster0.7pqzm.mongodb.net/?retryWrites=true&w=majority",
  secretOrKey: "12345"
};